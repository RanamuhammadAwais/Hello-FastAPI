def my_first_function ()->str:
    return"hello world"


result = my_first_function()
print(result)